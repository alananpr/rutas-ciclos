import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prod2',
  templateUrl: './prod2.component.html',
  styleUrls: ['./prod2.component.scss']
})
export class Prod2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
