import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './access/login/login.component';
import { RecoverComponent } from './access/recover/recover.component';
import { RegistryComponent } from './access/registry/registry.component';
import { ProductosComponent } from './galeria/productos/productos.component';
import { NavbarComponent } from './home/navbar/navbar.component';
import { ViewComponent } from './home/view/view.component';



const routes: Routes = [
  {path: 'access', component: LoginComponent},
  {path: 'home', component: NavbarComponent},
  {path: 'main', component: ViewComponent},
  {path: 'registry', component: RegistryComponent},
  {path: 'recovery', component: RecoverComponent},
  {path: 'productos', component: ProductosComponent},
  {path: 'productos', loadChildren: ()=> import('./galeria/galeria.module').then(m => m.GaleriaModule)}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
