import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavbarComponent } from './navbar/navbar.component';
import { ViewComponent } from './view/view.component';
import { NotificationsComponent } from './notifications/notifications.component';



@NgModule({
  declarations: [
    NavbarComponent,
    ViewComponent,
    NotificationsComponent
  ],
  exports: [
    NavbarComponent
  ],
  imports: [
    CommonModule
  ]
})
export class HomeModule { }
