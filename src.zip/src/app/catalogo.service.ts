import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CatalogoService {

  lista:any[]=[
    {
      id:1,
      nombre: 'manzana',
      precio: '50',
      imagen: './assets/05.jpg'
    },
    {
      id:2,
      nombre: 'pera',
      precio: '25',
      imagen: './assets/06.jpg'
    }
  ];
  
  constructor() {}
  getProd()
  {
    return this.lista;
  }
  getProdId(clave:number)
  {
    return this.lista[clave];
  }
}
